﻿namespace MemeHub.Models.Enums
{
    public enum Category
    {
        Hilarious,
        Dank,
        Awesome,
    }
}