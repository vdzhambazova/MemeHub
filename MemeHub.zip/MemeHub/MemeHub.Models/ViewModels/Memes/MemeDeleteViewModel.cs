﻿namespace MemeHub.Models.ViewModels.Memes
{
    public class MemeDeleteViewModel
    {
        public int Id { get; set; }

        public string MemeImageUrl { get; set; }

        public string Caption { get; set; }
    }
}
