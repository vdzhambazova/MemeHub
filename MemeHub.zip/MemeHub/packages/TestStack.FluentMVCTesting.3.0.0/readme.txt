﻿FluentMVCTesting
==============

The main FluentMVCTesting NuGet package has been updated to support .NET 4.5 and MVC5. If you need .NET 4.0 / MVC4 support then use the new FluentMVCTesting.Mvc4 NuGet package.

* For the project homepage including the current README, see https://github.com/TestStack/TestStack.FluentMVCTesting
* To check for potential breaking changes in this release, see https://github.com/TestStack/TestStack.FluentMVCTesting/blob/master/BREAKING_CHANGES.md
* If you need to raise an issue or check for an existing issue, see https://github.com/TestStack/TestStack.FluentMVCTesting/issues